Makefile is provided. 
To compile the program, use "make all".
To compile objects first, use "make obj".
To clean up, use "make clean".

Developed under VS Code. The tasks.json and launch.json should be able to let you debug the program in VS Code.

